import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const DB_PATH = process.env.DB_PATH || path.join(process.cwd(), "data", "microzelen.db");

// Ensure data directory exists
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

export const db = new Database(DB_PATH);

// Enable WAL mode for better performance
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// ── SCHEMA ────────────────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    tin TEXT UNIQUE,
    type TEXT NOT NULL DEFAULT 'horeca', -- horeca | private | wholesale
    phone TEXT,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rs_waybill_id TEXT,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    date TEXT NOT NULL,
    items TEXT NOT NULL, -- JSON
    total_gel REAL NOT NULL,
    status TEXT DEFAULT 'active', -- draft | active | cancelled
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    amount_gel REAL NOT NULL,
    date TEXT NOT NULL,
    method TEXT DEFAULT 'transfer', -- transfer | cash | card
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS partner_settlements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    period_start TEXT NOT NULL,
    period_end TEXT NOT NULL,
    total_revenue_gel REAL NOT NULL,
    natalia_share_gel REAL NOT NULL,
    sergei_share_gel REAL NOT NULL,
    natalia_paid_gel REAL DEFAULT 0,
    status TEXT DEFAULT 'pending', -- pending | settled
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    category TEXT NOT NULL, -- seeds | substrate | packaging | delivery | other
    description TEXT NOT NULL,
    amount_gel REAL NOT NULL,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// ── CLIENT OPERATIONS ─────────────────────────────────────────────────────────
export function upsertClient(name: string, tin?: string, type = "horeca", phone?: string, notes?: string) {
  if (tin) {
    const existing = db.prepare("SELECT * FROM clients WHERE tin = ?").get(tin) as any;
    if (existing) {
      db.prepare("UPDATE clients SET name=?, type=?, phone=?, notes=? WHERE tin=?")
        .run(name, type, phone || existing.phone, notes || existing.notes, tin);
      return db.prepare("SELECT * FROM clients WHERE tin = ?").get(tin);
    }
  }
  const r = db.prepare("INSERT INTO clients (name, tin, type, phone, notes) VALUES (?,?,?,?,?)")
    .run(name, tin || null, type, phone || null, notes || null);
  return db.prepare("SELECT * FROM clients WHERE id = ?").get(r.lastInsertRowid);
}

export function getClient(nameOrTin: string) {
  return (
    db.prepare("SELECT * FROM clients WHERE tin = ? OR LOWER(name) LIKE LOWER(?)").get(nameOrTin, `%${nameOrTin}%`) as any
  );
}

export function listClients() {
  return db.prepare("SELECT * FROM clients ORDER BY name").all() as any[];
}

// ── INVOICE OPERATIONS ────────────────────────────────────────────────────────
export function addInvoice(
  clientId: number,
  date: string,
  items: Array<{ name: string; quantity: number; price: number }>,
  totalGel: number,
  rsWaybillId?: string,
  notes?: string
) {
  const r = db.prepare(
    "INSERT INTO invoices (client_id, date, items, total_gel, rs_waybill_id, notes) VALUES (?,?,?,?,?,?)"
  ).run(clientId, date, JSON.stringify(items), totalGel, rsWaybillId || null, notes || null);
  return db.prepare("SELECT * FROM invoices WHERE id = ?").get(r.lastInsertRowid) as any;
}

export function getClientInvoices(clientId: number, dateFrom?: string, dateTo?: string) {
  let sql = "SELECT * FROM invoices WHERE client_id = ?";
  const params: any[] = [clientId];
  if (dateFrom) { sql += " AND date >= ?"; params.push(dateFrom); }
  if (dateTo)   { sql += " AND date <= ?"; params.push(dateTo); }
  sql += " ORDER BY date DESC";
  return db.prepare(sql).all(...params) as any[];
}

// ── PAYMENT OPERATIONS ────────────────────────────────────────────────────────
export function addPayment(clientId: number, amountGel: number, date: string, method = "transfer", notes?: string) {
  const r = db.prepare(
    "INSERT INTO payments (client_id, amount_gel, date, method, notes) VALUES (?,?,?,?,?)"
  ).run(clientId, amountGel, date, method, notes || null);
  return db.prepare("SELECT * FROM payments WHERE id = ?").get(r.lastInsertRowid) as any;
}

export function getClientPayments(clientId: number, dateFrom?: string, dateTo?: string) {
  let sql = "SELECT * FROM payments WHERE client_id = ?";
  const params: any[] = [clientId];
  if (dateFrom) { sql += " AND date >= ?"; params.push(dateFrom); }
  if (dateTo)   { sql += " AND date <= ?"; params.push(dateTo); }
  sql += " ORDER BY date DESC";
  return db.prepare(sql).all(...params) as any[];
}

// ── BALANCE ───────────────────────────────────────────────────────────────────
export function getClientBalance(clientId: number) {
  const invoicesTotal = (db.prepare(
    "SELECT COALESCE(SUM(total_gel),0) as total FROM invoices WHERE client_id = ? AND status != 'cancelled'"
  ).get(clientId) as any).total;

  const paymentsTotal = (db.prepare(
    "SELECT COALESCE(SUM(amount_gel),0) as total FROM payments WHERE client_id = ?"
  ).get(clientId) as any).total;

  return {
    invoiced: invoicesTotal,
    paid: paymentsTotal,
    balance: invoicesTotal - paymentsTotal, // positive = owes us, negative = overpaid
  };
}

// ── REPORTS ───────────────────────────────────────────────────────────────────
export function getRevenueReport(dateFrom: string, dateTo: string) {
  const revenue = (db.prepare(
    "SELECT COALESCE(SUM(total_gel),0) as total FROM invoices WHERE date >= ? AND date <= ? AND status != 'cancelled'"
  ).get(dateFrom, dateTo) as any).total;

  const lotksRow = db.prepare(
    "SELECT items FROM invoices WHERE date >= ? AND date <= ? AND status != 'cancelled'"
  ).all(dateFrom, dateTo) as any[];

  let totalLotki = 0;
  for (const row of lotksRow) {
    try {
      const items = JSON.parse(row.items);
      for (const item of items) totalLotki += item.quantity || 0;
    } catch {}
  }

  const payments = (db.prepare(
    "SELECT COALESCE(SUM(amount_gel),0) as total FROM payments WHERE date >= ? AND date <= ?"
  ).get(dateFrom, dateTo) as any).total;

  return { revenue, payments, totalLotki, dateFrom, dateTo };
}

export function getAllBalances() {
  const clients = listClients();
  return clients.map((c) => {
    const bal = getClientBalance(c.id);
    return { ...c, ...bal };
  }).filter((c) => c.invoiced > 0 || c.paid > 0);
}

export function addExpense(date: string, category: string, description: string, amountGel: number, notes?: string) {
  const r = db.prepare(
    "INSERT INTO expenses (date, category, description, amount_gel, notes) VALUES (?,?,?,?,?)"
  ).run(date, category, description, amountGel, notes || null);
  return db.prepare("SELECT * FROM expenses WHERE id = ?").get(r.lastInsertRowid) as any;
}

export function getExpenses(dateFrom?: string, dateTo?: string, category?: string) {
  let sql = "SELECT * FROM expenses WHERE 1=1";
  const params: any[] = [];
  if (dateFrom) { sql += " AND date >= ?"; params.push(dateFrom); }
  if (dateTo)   { sql += " AND date <= ?"; params.push(dateTo); }
  if (category) { sql += " AND category = ?"; params.push(category); }
  sql += " ORDER BY date DESC";
  return db.prepare(sql).all(...params) as any[];
}

// ── PARTNER SETTLEMENT ────────────────────────────────────────────────────────
export function calculatePartnerSettlement(dateFrom: string, dateTo: string, nataliaSharePct = 50) {
  const { revenue } = getRevenueReport(dateFrom, dateTo);
  const expenses = (db.prepare(
    "SELECT COALESCE(SUM(amount_gel),0) as total FROM expenses WHERE date >= ? AND date <= ?"
  ).get(dateFrom, dateTo) as any).total;

  const net = revenue - expenses;
  const nataliaShare = (net * nataliaSharePct) / 100;
  const sergeiShare = net - nataliaShare;

  return {
    period: `${dateFrom} — ${dateTo}`,
    grossRevenue: revenue,
    expenses,
    netProfit: net,
    nataliaSharePct,
    nataliaShare,
    sergeiShare,
  };
}
