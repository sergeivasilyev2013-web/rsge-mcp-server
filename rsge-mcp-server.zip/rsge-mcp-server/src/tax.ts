import { db } from "./db.js";

// ── GEORGIAN SMALL BUSINESS TAX (მცირე ბიზნესი) ───────────────────────────────
// Rate: 1% of turnover (gross revenue)
// Declaration: monthly, due by 15th of following month
// Quarterly report: due by 15th of month after quarter end
// Annual declaration: due by 1 April of following year

export const TAX_RATE = 0.01; // 1%

export interface MonthlyTaxReport {
  year: number;
  month: number;
  monthName: string;
  turnover: number;
  taxAmount: number;
  taxRate: number;
  dueDate: string;
  invoiceCount: number;
  lotokCount: number;
  status: "pending" | "due_soon" | "overdue" | "filed";
}

export interface QuarterlyReport {
  year: number;
  quarter: number;
  months: MonthlyTaxReport[];
  totalTurnover: number;
  totalTax: number;
  dueDate: string;
}

export interface AnnualReport {
  year: number;
  quarters: QuarterlyReport[];
  totalTurnover: number;
  totalTax: number;
  totalExpenses: number;
  netIncome: number;
  dueDate: string;
}

const MONTH_NAMES_RU = [
  "", "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
];

function getMonthStatus(year: number, month: number): "pending" | "due_soon" | "overdue" | "filed" {
  const filed = db.prepare(
    "SELECT 1 FROM tax_filings WHERE year=? AND month=? AND type='monthly'"
  ).get(year, month);
  if (filed) return "filed";

  const now = new Date();
  const dueDate = new Date(year, month, 15); // 15th of next month
  const diffDays = Math.floor((dueDate.getTime() - now.getTime()) / 86400000);

  if (diffDays < 0) return "overdue";
  if (diffDays <= 5) return "due_soon";
  return "pending";
}

export function getMonthlyTaxReport(year: number, month: number): MonthlyTaxReport {
  const dateFrom = `${year}-${String(month).padStart(2, "0")}-01`;
  const lastDay = new Date(year, month, 0).getDate();
  const dateTo = `${year}-${String(month).padStart(2, "0")}-${lastDay}`;

  const turnoverRow = db.prepare(
    "SELECT COALESCE(SUM(total_gel),0) as total, COUNT(*) as cnt FROM invoices WHERE date >= ? AND date <= ? AND status != 'cancelled'"
  ).get(dateFrom, dateTo) as any;

  const invoicesData = db.prepare(
    "SELECT items FROM invoices WHERE date >= ? AND date <= ? AND status != 'cancelled'"
  ).all(dateFrom, dateTo) as any[];

  let lotokCount = 0;
  for (const row of invoicesData) {
    try {
      const items = JSON.parse(row.items);
      for (const item of items) lotokCount += item.quantity || 0;
    } catch {}
  }

  const turnover = turnoverRow.total;
  const taxAmount = Math.round(turnover * TAX_RATE * 100) / 100;
  const dueMonth = month === 12 ? 1 : month + 1;
  const dueYear = month === 12 ? year + 1 : year;
  const dueDate = `${dueYear}-${String(dueMonth).padStart(2, "0")}-15`;

  return {
    year,
    month,
    monthName: MONTH_NAMES_RU[month],
    turnover,
    taxAmount,
    taxRate: TAX_RATE * 100,
    dueDate,
    invoiceCount: turnoverRow.cnt,
    lotokCount,
    status: getMonthStatus(year, month),
  };
}

export function getQuarterlyReport(year: number, quarter: number): QuarterlyReport {
  const startMonth = (quarter - 1) * 3 + 1;
  const months = [startMonth, startMonth + 1, startMonth + 2]
    .map((m) => getMonthlyTaxReport(year, m));

  const totalTurnover = months.reduce((s, m) => s + m.turnover, 0);
  const totalTax = Math.round(totalTurnover * TAX_RATE * 100) / 100;

  const dueMonth = quarter * 3 + 1;
  const dueYear = dueMonth > 12 ? year + 1 : year;
  const dueMonthNorm = dueMonth > 12 ? dueMonth - 12 : dueMonth;
  const dueDate = `${dueYear}-${String(dueMonthNorm).padStart(2, "0")}-15`;

  return { year, quarter, months, totalTurnover, totalTax, dueDate };
}

export function getAnnualReport(year: number): AnnualReport {
  const quarters = [1, 2, 3, 4].map((q) => getQuarterlyReport(year, q));
  const totalTurnover = quarters.reduce((s, q) => s + q.totalTurnover, 0);
  const totalTax = Math.round(totalTurnover * TAX_RATE * 100) / 100;

  const expensesRow = db.prepare(
    "SELECT COALESCE(SUM(amount_gel),0) as total FROM expenses WHERE date >= ? AND date <= ?"
  ).get(`${year}-01-01`, `${year}-12-31`) as any;

  const totalExpenses = expensesRow.total;
  const netIncome = totalTurnover - totalExpenses - totalTax;

  return {
    year,
    quarters,
    totalTurnover,
    totalTax,
    totalExpenses,
    netIncome,
    dueDate: `${year + 1}-04-01`,
  };
}

export function getUpcomingDeadlines(): Array<{ type: string; description: string; dueDate: string; urgency: string }> {
  const now = new Date();
  const deadlines: Array<{ type: string; description: string; dueDate: string; urgency: string }> = [];

  // Check last 3 months for unfiled declarations
  for (let i = 1; i <= 3; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const year = d.getFullYear();
    const month = d.getMonth() + 1;
    const report = getMonthlyTaxReport(year, month);

    if (report.status !== "filed" && report.turnover > 0) {
      const dueDate = new Date(report.dueDate);
      const diffDays = Math.floor((dueDate.getTime() - now.getTime()) / 86400000);
      deadlines.push({
        type: "monthly",
        description: `Декларация за ${report.monthName} ${year} — оборот ${report.turnover} GEL, налог ${report.taxAmount} GEL`,
        dueDate: report.dueDate,
        urgency: diffDays < 0 ? "🔴 ПРОСРОЧЕНА" : diffDays <= 5 ? "🟡 Срочно" : "🟢 Ожидает",
      });
    }
  }

  return deadlines;
}

export function markMonthFiled(year: number, month: number, notes?: string) {
  // Ensure tax_filings table exists
  db.exec(`CREATE TABLE IF NOT EXISTS tax_filings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    year INTEGER NOT NULL,
    month INTEGER,
    quarter INTEGER,
    type TEXT NOT NULL,
    turnover REAL,
    tax_paid REAL,
    filed_at TEXT DEFAULT (datetime('now')),
    notes TEXT
  )`);

  const report = getMonthlyTaxReport(year, month);
  db.prepare(
    "INSERT OR REPLACE INTO tax_filings (year, month, type, turnover, tax_paid, notes) VALUES (?,?,?,?,?,?)"
  ).run(year, month, "monthly", report.turnover, report.taxAmount, notes || null);

  return report;
}

export function formatMonthlyForDeclaration(year: number, month: number): string {
  const r = getMonthlyTaxReport(year, month);
  return `
📋 ДЕКЛАРАЦИЯ ЗА ${r.monthName.toUpperCase()} ${r.year}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Оборот (валовая выручка):  ${r.turnover.toFixed(2)} GEL
Ставка налога:             ${r.taxRate}%
СУММА НАЛОГА К УПЛАТЕ:     ${r.taxAmount.toFixed(2)} GEL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Срок подачи:               ${r.dueDate}
Накладных выставлено:      ${r.invoiceCount} шт
Лотков продано:            ${r.lotokCount} шт

➡️ Зайди в rs.ge → Декларации → Малый бизнес
   Введи оборот: ${r.turnover.toFixed(2)} GEL
   Налог спишется автоматически: ${r.taxAmount.toFixed(2)} GEL
`.trim();
}
