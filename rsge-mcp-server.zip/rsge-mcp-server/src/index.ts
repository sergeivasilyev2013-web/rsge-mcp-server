import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

import {
  upsertClient, getClient, listClients,
  addInvoice, getClientInvoices,
  addPayment, getClientPayments,
  getClientBalance, getRevenueReport, getAllBalances,
  addExpense, getExpenses, calculatePartnerSettlement,
} from "./db.js";

import { rsCreateWaybill, rsLookupTin, rsGetWaybills } from "./rsge.js";

import {
  getMonthlyTaxReport, getQuarterlyReport, getAnnualReport,
  getUpcomingDeadlines, markMonthFiled, formatMonthlyForDeclaration,
} from "./tax.js";

// ── HELPERS ───────────────────────────────────────────────────────────────────
function today(): string {
  return new Date().toISOString().split("T")[0];
}

function formatBalance(bal: { invoiced: number; paid: number; balance: number }) {
  if (bal.balance > 0) return `Долг: ${bal.balance.toFixed(2)} GEL`;
  if (bal.balance < 0) return `Переплата: ${Math.abs(bal.balance).toFixed(2)} GEL`;
  return "Расчёт закрыт ✅";
}

// ── SERVER ────────────────────────────────────────────────────────────────────
const server = new Server(
  { name: "rsge-microzelen", version: "2.0.0" },
  { capabilities: { tools: {} } }
);

// ── TOOLS LIST ────────────────────────────────────────────────────────────────
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    // CLIENTS
    {
      name: "add_client",
      description: "Добавить нового клиента в базу. Указать название, ИНН, тип (horeca/private/wholesale), телефон.",
      inputSchema: {
        type: "object",
        properties: {
          name: { type: "string", description: "Название клиента или ФИО" },
          tin: { type: "string", description: "ИНН (9 цифр), необязательно" },
          type: { type: "string", enum: ["horeca", "private", "wholesale"], description: "Тип: horeca, private, wholesale" },
          phone: { type: "string", description: "Телефон" },
          notes: { type: "string", description: "Заметки" },
        },
        required: ["name"],
      },
    },
    {
      name: "list_clients",
      description: "Показать список всех клиентов с балансами",
      inputSchema: { type: "object", properties: {} },
    },
    // INVOICES
    {
      name: "create_invoice",
      description: "Создать накладную — записать в базу и отправить в rs.ge. Используй для выставления счёта клиенту на микрозелень.",
      inputSchema: {
        type: "object",
        properties: {
          client_name: { type: "string", description: "Название клиента (из базы)" },
          items: {
            type: "array",
            description: "Товары",
            items: {
              type: "object",
              properties: {
                name: { type: "string", description: "Название, напр. 'Микрозелень на корню'" },
                quantity: { type: "number", description: "Количество лотков" },
                price: { type: "number", description: "Цена за лоток в GEL" },
              },
              required: ["name", "quantity", "price"],
            },
          },
          date: { type: "string", description: "Дата YYYY-MM-DD, по умолчанию сегодня" },
          notes: { type: "string", description: "Примечание" },
        },
        required: ["client_name", "items"],
      },
    },
    {
      name: "get_client_invoices",
      description: "Показать все накладные клиента за период",
      inputSchema: {
        type: "object",
        properties: {
          client_name: { type: "string" },
          date_from: { type: "string", description: "YYYY-MM-DD" },
          date_to: { type: "string", description: "YYYY-MM-DD" },
        },
        required: ["client_name"],
      },
    },
    // PAYMENTS
    {
      name: "record_payment",
      description: "Записать оплату от клиента. Используй когда клиент заплатил.",
      inputSchema: {
        type: "object",
        properties: {
          client_name: { type: "string", description: "Название клиента" },
          amount_gel: { type: "number", description: "Сумма оплаты в GEL" },
          date: { type: "string", description: "Дата YYYY-MM-DD, по умолчанию сегодня" },
          method: { type: "string", enum: ["transfer", "cash", "card"], description: "Способ оплаты" },
          notes: { type: "string", description: "Примечание" },
        },
        required: ["client_name", "amount_gel"],
      },
    },
    // BALANCE & RECONCILIATION
    {
      name: "get_client_balance",
      description: "Показать баланс клиента: долг, оплаты, акт сверки",
      inputSchema: {
        type: "object",
        properties: {
          client_name: { type: "string" },
          date_from: { type: "string", description: "Начало периода для акта сверки" },
          date_to: { type: "string", description: "Конец периода для акта сверки" },
        },
        required: ["client_name"],
      },
    },
    {
      name: "get_all_balances",
      description: "Показать долги всех клиентов — общая картина кто сколько должен",
      inputSchema: { type: "object", properties: {} },
    },
    // REPORTS
    {
      name: "revenue_report",
      description: "Отчёт по выручке за период: сумма, лотки, оплаты",
      inputSchema: {
        type: "object",
        properties: {
          date_from: { type: "string", description: "YYYY-MM-DD" },
          date_to: { type: "string", description: "YYYY-MM-DD" },
        },
        required: ["date_from", "date_to"],
      },
    },
    // EXPENSES
    {
      name: "add_expense",
      description: "Записать расход (семена, субстрат, упаковка, доставка, прочее)",
      inputSchema: {
        type: "object",
        properties: {
          description: { type: "string", description: "Что купили" },
          amount_gel: { type: "number", description: "Сумма в GEL" },
          category: { type: "string", enum: ["seeds", "substrate", "packaging", "delivery", "other"], description: "Категория" },
          date: { type: "string", description: "Дата YYYY-MM-DD" },
        },
        required: ["description", "amount_gel", "category"],
      },
    },
    // PARTNER SETTLEMENT
    {
      name: "partner_settlement",
      description: "Расчёт с Натальей Шевченко (партнёр) за период — выручка, расходы, доля каждого",
      inputSchema: {
        type: "object",
        properties: {
          date_from: { type: "string", description: "YYYY-MM-DD" },
          date_to: { type: "string", description: "YYYY-MM-DD" },
          natalia_share_pct: { type: "number", description: "Доля Натальи в % (по умолчанию 50)" },
        },
        required: ["date_from", "date_to"],
      },
    },
    // TAX
    {
      name: "tax_monthly",
      description: "Расчёт налога за месяц (малый бизнес 1%) + инструкция как подать декларацию в rs.ge",
      inputSchema: {
        type: "object",
        properties: {
          year: { type: "number", description: "Год, напр. 2026" },
          month: { type: "number", description: "Месяц 1-12" },
        },
        required: ["year", "month"],
      },
    },
    {
      name: "tax_quarterly",
      description: "Квартальный налоговый отчёт",
      inputSchema: {
        type: "object",
        properties: {
          year: { type: "number" },
          quarter: { type: "number", description: "Квартал 1-4" },
        },
        required: ["year", "quarter"],
      },
    },
    {
      name: "tax_annual",
      description: "Годовая декларация о доходах — полный итог года",
      inputSchema: {
        type: "object",
        properties: {
          year: { type: "number" },
        },
        required: ["year"],
      },
    },
    {
      name: "tax_deadlines",
      description: "Показать ближайшие налоговые дедлайны и незакрытые декларации",
      inputSchema: { type: "object", properties: {} },
    },
    {
      name: "mark_tax_filed",
      description: "Отметить что декларация за месяц подана",
      inputSchema: {
        type: "object",
        properties: {
          year: { type: "number" },
          month: { type: "number" },
          notes: { type: "string" },
        },
        required: ["year", "month"],
      },
    },
    // RS.GE
    {
      name: "lookup_tin",
      description: "Узнать название компании по ИНН через rs.ge",
      inputSchema: {
        type: "object",
        properties: { tin: { type: "string" } },
        required: ["tin"],
      },
    },
  ],
}));

// ── TOOL HANDLERS ─────────────────────────────────────────────────────────────
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: rawArgs } = request.params;
  const args = (rawArgs || {}) as Record<string, any>;

  try {
    let result: any;

    // ── CLIENTS ──
    if (name === "add_client") {
      const client = upsertClient(args.name, args.tin, args.type || "horeca", args.phone, args.notes);
      result = { success: true, client, message: `✅ Клиент "${args.name}" добавлен` };
    }
    else if (name === "list_clients") {
      const clients = listClients();
      const withBalances = clients.map((c) => {
        const bal = getClientBalance(c.id);
        return { ...c, ...bal, balanceStr: formatBalance(bal) };
      });
      result = { clients: withBalances, total: clients.length };
    }

    // ── INVOICES ──
    else if (name === "create_invoice") {
      const client = getClient(args.client_name);
      if (!client) throw new Error(`Клиент "${args.client_name}" не найден. Сначала добавь через add_client.`);

      const invoiceDate = args.date || today();
      const total = args.items.reduce((s: number, i: any) => s + i.quantity * i.price, 0);

      // Try rs.ge, but don't fail if no credentials
      let rsWaybillId: string | undefined;
      if (process.env.RS_SERVICE_USER && process.env.RS_SERVICE_PASSWORD && client.tin) {
        try {
          rsWaybillId = await rsCreateWaybill(client.tin, client.name, args.items, invoiceDate);
        } catch (e: any) {
          console.error("rs.ge error:", e.message);
        }
      }

      const invoice = addInvoice(client.id, invoiceDate, args.items, total, rsWaybillId, args.notes);
      const bal = getClientBalance(client.id);

      result = {
        success: true,
        invoice_id: invoice.id,
        rs_waybill_id: rsWaybillId || "не синхронизировано с rs.ge",
        client: client.name,
        items: args.items,
        total_gel: total,
        date: invoiceDate,
        new_balance: formatBalance(bal),
        message: `✅ Накладная #${invoice.id} создана. Сумма: ${total} GEL. ${formatBalance(bal)}`,
      };
    }
    else if (name === "get_client_invoices") {
      const client = getClient(args.client_name);
      if (!client) throw new Error(`Клиент "${args.client_name}" не найден`);
      const invoices = getClientInvoices(client.id, args.date_from, args.date_to);
      result = { client: client.name, invoices, total: invoices.length };
    }

    // ── PAYMENTS ──
    else if (name === "record_payment") {
      const client = getClient(args.client_name);
      if (!client) throw new Error(`Клиент "${args.client_name}" не найден`);
      const payment = addPayment(client.id, args.amount_gel, args.date || today(), args.method || "transfer", args.notes);
      const bal = getClientBalance(client.id);
      result = {
        success: true,
        payment_id: payment.id,
        client: client.name,
        amount: args.amount_gel,
        new_balance: formatBalance(bal),
        message: `✅ Оплата ${args.amount_gel} GEL от "${client.name}" записана. ${formatBalance(bal)}`,
      };
    }

    // ── BALANCE ──
    else if (name === "get_client_balance") {
      const client = getClient(args.client_name);
      if (!client) throw new Error(`Клиент "${args.client_name}" не найден`);
      const bal = getClientBalance(client.id);
      const invoices = getClientInvoices(client.id, args.date_from, args.date_to);
      const payments = getClientPayments(client.id, args.date_from, args.date_to);

      const lines = [
        `📋 АКТ СВЕРКИ — ${client.name}`,
        `${"─".repeat(40)}`,
        `Период: ${args.date_from || "начало"} — ${args.date_to || "сегодня"}`,
        ``,
        `НАКЛАДНЫЕ:`,
        ...invoices.map((inv: any) => {
          const items = JSON.parse(inv.items);
          const desc = items.map((i: any) => `${i.quantity}лт × ${i.price}GEL`).join(", ");
          return `  ${inv.date}  #${inv.id}  ${desc}  = ${inv.total_gel} GEL`;
        }),
        `  ИТОГО выставлено: ${bal.invoiced.toFixed(2)} GEL`,
        ``,
        `ОПЛАТЫ:`,
        ...payments.map((p: any) => `  ${p.date}  ${p.amount_gel} GEL (${p.method})`),
        `  ИТОГО оплачено: ${bal.paid.toFixed(2)} GEL`,
        ``,
        `${"─".repeat(40)}`,
        `БАЛАНС: ${formatBalance(bal)}`,
      ];

      result = {
        client: client.name,
        balance: bal,
        balanceStr: formatBalance(bal),
        reconciliation: lines.join("\n"),
        invoices,
        payments,
      };
    }
    else if (name === "get_all_balances") {
      const balances = getAllBalances();
      const totalDebt = balances.filter((c) => c.balance > 0).reduce((s, c) => s + c.balance, 0);
      result = {
        clients: balances.map((c) => ({ name: c.name, type: c.type, balanceStr: formatBalance(c) })),
        totalDebt: `Общий долг: ${totalDebt.toFixed(2)} GEL`,
      };
    }

    // ── REPORTS ──
    else if (name === "revenue_report") {
      const rep = getRevenueReport(args.date_from, args.date_to);
      result = {
        ...rep,
        message: `📊 ${args.date_from} — ${args.date_to}\nВыручка: ${rep.revenue.toFixed(2)} GEL\nОплачено: ${rep.payments.toFixed(2)} GEL\nЛотков продано: ${rep.totalLotki}`,
      };
    }

    // ── EXPENSES ──
    else if (name === "add_expense") {
      const exp = addExpense(args.date || today(), args.category, args.description, args.amount_gel, args.notes);
      result = { success: true, expense: exp, message: `✅ Расход ${args.amount_gel} GEL записан: ${args.description}` };
    }

    // ── PARTNER ──
    else if (name === "partner_settlement") {
      const settlement = calculatePartnerSettlement(args.date_from, args.date_to, args.natalia_share_pct || 50);
      const lines = [
        `💼 РАСЧЁТ С НАТАЛЬЕЙ ШЕВЧЕНКО`,
        `${"─".repeat(40)}`,
        `Период: ${settlement.period}`,
        `Валовая выручка:    ${settlement.grossRevenue.toFixed(2)} GEL`,
        `Расходы:           -${settlement.expenses.toFixed(2)} GEL`,
        `Чистая прибыль:     ${settlement.netProfit.toFixed(2)} GEL`,
        `${"─".repeat(40)}`,
        `Доля Натальи (${settlement.nataliaSharePct}%): ${settlement.nataliaShare.toFixed(2)} GEL`,
        `Доля Сергея   (${100 - settlement.nataliaSharePct}%): ${settlement.sergeiShare.toFixed(2)} GEL`,
      ];
      result = { ...settlement, formatted: lines.join("\n") };
    }

    // ── TAX ──
    else if (name === "tax_monthly") {
      const report = getMonthlyTaxReport(args.year, args.month);
      const formatted = formatMonthlyForDeclaration(args.year, args.month);
      result = { ...report, formatted };
    }
    else if (name === "tax_quarterly") {
      const report = getQuarterlyReport(args.year, args.quarter);
      const lines = [
        `📋 КВАРТАЛЬНЫЙ ОТЧЁТ Q${args.quarter} ${args.year}`,
        `${"─".repeat(40)}`,
        ...report.months.map((m) => `${m.monthName}: ${m.turnover.toFixed(2)} GEL → налог ${m.taxAmount.toFixed(2)} GEL`),
        `${"─".repeat(40)}`,
        `ИТОГО оборот: ${report.totalTurnover.toFixed(2)} GEL`,
        `ИТОГО налог:  ${report.totalTax.toFixed(2)} GEL`,
        `Срок сдачи:   ${report.dueDate}`,
      ];
      result = { ...report, formatted: lines.join("\n") };
    }
    else if (name === "tax_annual") {
      const report = getAnnualReport(args.year);
      const lines = [
        `📋 ГОДОВАЯ ДЕКЛАРАЦИЯ ${args.year}`,
        `${"─".repeat(40)}`,
        ...report.quarters.map((q) => `Q${q.quarter}: оборот ${q.totalTurnover.toFixed(2)} GEL, налог ${q.totalTax.toFixed(2)} GEL`),
        `${"─".repeat(40)}`,
        `Валовой оборот:   ${report.totalTurnover.toFixed(2)} GEL`,
        `Уплачено налогов: ${report.totalTax.toFixed(2)} GEL`,
        `Расходы бизнеса:  ${report.totalExpenses.toFixed(2)} GEL`,
        `Чистый доход:     ${report.netIncome.toFixed(2)} GEL`,
        `Срок подачи:      ${report.dueDate}`,
      ];
      result = { ...report, formatted: lines.join("\n") };
    }
    else if (name === "tax_deadlines") {
      const deadlines = getUpcomingDeadlines();
      result = {
        deadlines,
        message: deadlines.length === 0
          ? "✅ Все декларации поданы, просроченных нет"
          : `⚠️ Найдено ${deadlines.length} незакрытых деклараций`,
      };
    }
    else if (name === "mark_tax_filed") {
      const report = markMonthFiled(args.year, args.month, args.notes);
      result = { success: true, message: `✅ Декларация за ${report.monthName} ${args.year} отмечена как поданная` };
    }

    // ── RS.GE ──
    else if (name === "lookup_tin") {
      const companyName = await rsLookupTin(args.tin);
      result = { tin: args.tin, name: companyName || "Не найдено" };
    }

    else {
      throw new Error(`Неизвестный инструмент: ${name}`);
    }

    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };

  } catch (error: any) {
    return {
      content: [{ type: "text", text: `❌ Ошибка: ${error.message}` }],
      isError: true,
    };
  }
});

// ── START ─────────────────────────────────────────────────────────────────────
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("✅ Microzelen MCP Server v2.0 запущен");
}

main().catch(console.error);
